End Remastered – Eye Boss Overrides (Simple v3)
----------------------------------------------
• Names per your mapping
• Tooltips simplified for a cleaner tone
• Place ABOVE other packs; edit assets/endrem/lang/en_us.json to tweak

Built: 2025-10-09T22:33:39